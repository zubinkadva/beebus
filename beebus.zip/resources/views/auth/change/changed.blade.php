<div class="alert alert-success">
    <i class="ace-icon fa fa-check-circle"></i> {{$success}}
</div>

<div class="clearfix">
    <button class="btn btn-success btn-sm btn-round center" data-dismiss="modal">
        <i class="ace-icon fa fa-check fa-fw"></i>
        <span class="bigger-110">OK</span>
    </button>
</div>