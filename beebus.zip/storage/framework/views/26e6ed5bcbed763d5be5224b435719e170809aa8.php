var polygonCoordinates_<?php echo $id; ?> = [
	<?php $__currentLoopData = $options['coordinates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordinate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		new google.maps.LatLng(<?php echo $coordinate['latitude']; ?>, <?php echo $coordinate['longitude']; ?>),
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
];

var polygon_<?php echo $id; ?> = new google.maps.Polygon({
	paths: polygonCoordinates_<?php echo $id; ?>,
	strokeColor: '<?php echo $options['strokeColor']; ?>',
	strokeOpacity: <?php echo $options['strokeOpacity']; ?>,
	strokeWeight: <?php echo $options['strokeWeight']; ?>,
	fillColor: '<?php echo $options['fillColor']; ?>',
	fillOpacity: <?php echo $options['fillOpacity']; ?>,
	editable: <?php echo $options['editable'] ? 'true' : 'false'; ?>

});

polygon_<?php echo $id; ?>.setMap(<?php echo $options['map']; ?>);

shapes.push({
	'polygon_<?php echo $id; ?>': polygon_<?php echo $id; ?>

});