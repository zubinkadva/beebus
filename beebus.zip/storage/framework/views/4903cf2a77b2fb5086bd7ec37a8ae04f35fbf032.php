var circleCoordinates_<?php echo $id; ?> = (
	<?php $__currentLoopData = $options['coordinates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coordinate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		new google.maps.LatLng(<?php echo $coordinate['latitude']; ?>, <?php echo $coordinate['longitude']; ?>)
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
);

var circle_<?php echo $id; ?> = new google.maps.Circle({
	strokeColor: '<?php echo $options['strokeColor']; ?>',
	strokeOpacity: <?php echo $options['strokeOpacity']; ?>,
	strokeWeight: <?php echo $options['strokeWeight']; ?>,
	fillColor: '<?php echo $options['fillColor']; ?>',
	fillOpacity: <?php echo $options['fillOpacity']; ?>,
	center: circleCoordinates_<?php echo $id; ?>,
	radius: <?php echo $options['radius']; ?>,
	editable: <?php echo $options['editable'] ? 'true' : 'false'; ?>

});

circle_<?php echo $id; ?>.setMap(<?php echo $options['map']; ?>);

shapes.push({
	'circle_<?php echo $id; ?>': circle_<?php echo $id; ?>

});