<?php if(!empty($error)): ?>
    <div class="alert alert-danger">
        <i class="ace-icon fa fa-exclamation-circle fa-fw"></i> <?php echo e($error); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(url('auth/verify')); ?>" method="post" id="login-form">
    <?php echo e(csrf_field()); ?>

    <?php if(!empty($_id)): ?>
        <input type="hidden" id="_id" name="_id" value="<?php echo e($_id); ?>">
    <?php endif; ?>
    <fieldset>
        <div class="form-group">
            <span class="block input-icon input-icon-right">
                <input type="password" class="form-control" id="_password" name="_password"
                       placeholder="Password"/>
                <i class="ace-icon fa fa-lock fa-fw"></i>
            </span>
        </div>

        <div class="space"></div>

        <div class="clearfix">
            <button type="submit" class="btn btn-sm btn-primary width-100 btn-login">
                <i class="ace-icon fa fa-key fa-fw"></i>
                <span class="bigger-110">Login</span>
            </button>
        </div>
    </fieldset>
</form>

<?php echo $__env->make('auth.loginjs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>