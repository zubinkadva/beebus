<p>
    <a class="btn btn-white btn-success btn-print btn-round" href="<?php echo e(url('print/'.encrypt($location->id).'')); ?>"
       rel="noopener noreferrer"
       target="_blank">
        <i class="ace-icon fa fa-print fa-fw"></i> Print
    </a>

    <a class="btn btn-white btn-info btn-edit pull-right btn-round">
        <i class="ace-icon fa fa-edit fa-fw"></i> Edit
    </a>
</p>

<div class="details">
    <input type="hidden" id="_id" name="_id" value="<?php echo e(encrypt($location->id)); ?>">
    <table class="table table-striped">
        <tr>
            <td><b>Location</b></td>
            <td><span class="text text-success"><?php echo e($location->name); ?></span></td>
        </tr>
        <tr>
            <td><b>Gate?</b></td>
            <td><i class="ace-icon fa fa-<?php echo e($location->gate?'check green':'times red'); ?>"> </i></td>
        </tr>
        <?php if($location->gate): ?>
            <tr>
                <td><b>Combination</b></td>
                <td>
                    <?php if(!empty($location->combination)): ?>
                        <span class="text text-success"><?php echo e(join('-',str_split($location->combination))); ?></span>
                    <?php else: ?>
                        <span class="label label-danger">Latched</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endif; ?>
        <tr>
            <td><b># Pallets</b></td>
            <td>
                <?php if(!empty($location->pallets)): ?>
                    <span class="badge badge-success"><?php echo e($location->pallets); ?></span> or
                    <span class="badge badge-info"><?php echo e($location->pallets*4); ?> Hives</span>
                <?php else: ?>
                    <i class="ace-icon fa fa-question-circle red"></i>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td><b>Owned by</b></td>
            <td>
                <?php if(!empty($location->owned_by)): ?>
                    <span class="text text-success"><?php echo e($location->owned_by); ?></span>
                <?php else: ?>
                    <i class="ace-icon fa fa-question-circle red"></i>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td><b>Flowers</b></td>
            <td>
                <?php if(!empty($location->flowers)): ?>
                    <span class="text text-success"><?php echo e($location->flowers); ?></span>
                <?php else: ?>
                    <i class="ace-icon fa fa-question-circle red"></i>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td><b>Fencing</b></td>
            <td>
                <?php if(!empty($location->fencing)): ?>
                    <span class="text text-success"><?php echo e($location->fencing); ?></span>
                <?php else: ?>
                    <i class="ace-icon fa fa-times red"></i>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td><b>Payments</b></td>
            <td>
                <?php if(!empty($location->payments)): ?>
                    <span class="text text-success"><?php echo e($location->payments); ?></span>
                <?php else: ?>
                    <i class="ace-icon fa fa-question-circle red"></i>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td><b>Notes</b></td>
            <td>
                <?php if(!empty($location->notes)): ?>
                    <span class="text text-success"><?php echo e($location->notes); ?></span>
                <?php else: ?>
                    <i class="ace-icon fa fa-question-circle red"></i>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <?php if(!empty($images)): ?>
        <div>
            <ul class="ace-thumbnails clearfix">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('image/'.$image->name)); ?>" data-rel="colorbox" class="cboxElement">
                            <img width="100" height="100" alt="150x150" src="<?php echo e(url('image/'.$image->name)); ?>">
                            <div class="text">
                                <div class="inner"><i class="ace-icon fa fa-eye fa-fw blue"></i> View</div>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>

<?php echo $__env->make('showjs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>