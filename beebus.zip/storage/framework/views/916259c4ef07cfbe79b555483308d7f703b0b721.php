<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta charset="utf-8"/>
    <title><?php echo e(env('APP_NAME')); ?></title>

    <meta name="description" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>


    <style>
        html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}
    </style>

</head>

<body style="background: white; ">
<table width="100%">
    <tr>
        <td><h2>Location: <?php echo e($location->name); ?></h2></td>
        <td style="text-align: right">
            <h2><?php echo e(explode(' ', env('APP_NAME'))[0]); ?> <?php echo e(explode(' ', env('APP_NAME'))[1]); ?></h2>
        </td>
    </tr>
</table>
<hr>
<br>
<table cellpadding="10px" style="border-spacing: 50px 0">
    <tr>
        <td style="text-align: right"><b>Latitude</b></td>
        <td><?php echo e($location->lat); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Longitude</b></td>
        <td><?php echo e($location->lng); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Gate</b></td>
        <td><?php echo e($location->gate?'Yes':'No'); ?></td>
    </tr>
    <?php if($location->gate): ?>
    <tr>
        <td style="text-align: right"><b>Combination</b></td>
        <td><?php echo e($location->combination?join('-',str_split($location->combination)):'Latched'); ?></td>
    </tr>
    <?php endif; ?>
    <tr>
        <td style="text-align: right"><b>Pallets</b></td>
        <td><?php echo e($location->pallets?$location->pallets:'No information available'); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Owned by</b></td>
        <td><?php echo e($location->owned_by?$location->owned_by:'No information available'); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Flowers</b></td>
        <td><?php echo e($location->flowers?$location->flowers:'No information available'); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Fencing</b></td>
        <td><?php echo e($location->fencing?$location->fencing:'No information available'); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Payments</b></td>
        <td><?php echo e($location->payments?$location->payments:'No information available'); ?></td>
    </tr>
    <tr>
        <td style="text-align: right"><b>Notes</b></td>
        <td><?php echo e($location->notes?$location->notes:'No information available'); ?></td>
    </tr>
</table>

</body>
</html>
