<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('assets/css/dropzone.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inline-scripts'); ?>
    <script src="<?php echo e(asset('assets/js/dropzone.min.js')); ?>"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            Dropzone.autoDiscover = false;

            var first = new Dropzone("#editfiles", {
                url: '<?php echo e(url('editLocation')); ?>',
                autoProcessQueue: false,
                uploadMultiple: true,
                parallelUploads: 5,
                maxFiles: 5,
                maxFilesize: 1024,
                acceptedFiles: 'image/*',
                addRemoveLinks: true,
                dictDefaultMessage: '<b>Drop files here or click to choose</b><br>' +
                '<i class="upload-icon ace-icon fa fa-cloud-upload blue fa-3x"></i>',

                init: function () {
                    dzClosure = this;
                    document.getElementById("edit-submit-all").addEventListener("click", function (e) {
                        e.preventDefault();
                        e.stopPropagation();

                        if (dzClosure.getQueuedFiles().length > 0) {
                            dzClosure.processQueue();
                        } else {
                            dzClosure.uploadFiles([{name: ''}]); //send empty
                        }

                    });

                    this.on("sendingmultiple", function (data, xhr, formData) {
                        formData.append("_token", $('[name=_token]').val());
                        formData.append("edit-name", $("#edit-name").val());
                        formData.append("edit-lat", $("#edit-lat").val());
                        formData.append("edit-lng", $("#edit-lng").val());
                        formData.append("edit-gate", $("#edit-gate").val());
                        formData.append("edit-combination", $("#edit-combination").val());
                        formData.append("edit-pallets", $("#edit-pallets").val());
                        formData.append("edit-owned_by", $("#edit-owned_by").val());
                        formData.append("edit-flowers", $("#edit-flowers").val());
                        formData.append("edit-fencing", $("#edit-fencing").val());
                        formData.append("edit-payments", $("#edit-payments").val());
                        formData.append("edit-notes", $("#edit-notes").val());
                    });

                    this.on("complete", function (file) {
                        if (this.getUploadingFiles().length === 0 && this.getQueuedFiles().length === 0) {
                            bootbox.alert("Location added successfully. Refreshing...");
                            setTimeout(function () {
                                window.location.reload();
                            }, 2000);
                        }
                    });
                }
            });


        });

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>


    <form id="show-edit-form" name="show-edit-form" class="form-horizontal" role="form" method="post"
          enctype="multipart/form-data" action="<?php echo e(url('editLocation')); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" id="location_id" name="location_id" value="<?php echo e($location->id); ?>">

        <div class="form-group">
            <div class="col-xs-12">
                <input type="text" id="edit-name" name="edit-name" placeholder="Name" class="width-100"
                       value="<?php echo e($location->name); ?>">
            </div>
        </div>

        <div class="widget-box">
            <div class="widget-header">
                <h5 class="widget-title">Position</h5>
            </div>

            <div class="widget-body">
                <div class="widget-main">
                    <div class="form-group">
                        <div class="col-xs-12">
                            <div class="alert alert-info">
                                <i class="ace-icon fa fa-exclamation-circle fa-fw"></i>
                                Enter coordinates below or click on the map
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-6">
                            <input type="text" id="edit-lat" name="edit-lat" placeholder="Latitude"
                                   class="width-100" value="<?php echo e($location->lat); ?>">
                        </div>
                        <div class="col-xs-6">
                            <input type="text" id="edit-lng" name="edit-lng" placeholder="Longitude"
                                   class="width-100" value="<?php echo e($location->lng); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>

        <div class="form-group">
            <div class="col-xs-12">
                <div class="checkbox">
                    <label>
                        <input id="edit-gate" name="edit-gate" type="checkbox" class="ace"
                               onchange="$('.lock-group').toggle('slow');" <?php echo e($location->gate ? 'checked': ''); ?>>
                        <span class="lbl"> Gate?</span>
                    </label>
                </div>
            </div>
        </div>

        <div class="form-group lock-group" style="display: <?php echo e($location->gate? 'block':'none'); ?>">
            <div class="col-xs-12">
                <input type="text" id="edit-combination" name="edit-combination" placeholder="Lock combination"
                       class="width-100" value="<?php echo e($location->combination); ?>">
            </div>
        </div>

        <div class="form-group">
            <div class="col-xs-12">
                <label class="control-text no-padding-right" for="pallets"> # Pallets</label>
                <input type="text" id="edit-pallets" name="edit-pallets"
                       class="spinbox-input form-control text-center" value="<?php echo e($location->pallets); ?>">
            </div>
        </div>

        <div class="form-group">
            <div class="col-xs-12">
                <input type="text" id="edit-owned_by" name="edit-owned_by" placeholder="Owned by"
                       class="width-100" value="<?php echo e($location->owned_by); ?>">
            </div>
        </div>

        <div class="form-group">
            <div class="col-xs-12">
                <input type="text" id="edit-flowers" name="edit-flowers" placeholder="Flowers" class="width-100"
                       value="<?php echo e($location->flowers); ?>">
            </div>
        </div>

        <div class="form-group">
            <div class="col-xs-12">
                <input type="text" id="edit-fencing" name="edit-fencing" placeholder="Fencing" class="width-100"
                       value="<?php echo e($location->fencing); ?>">
            </div>
        </div>

        <div class="form-group">
            <div class="col-xs-12">
                <input type="text" id="edit-payments" name="edit-payments" placeholder="Payments"
                       class="width-100" value="<?php echo e($location->payments); ?>">
            </div>
        </div>


        <div class="form-group">
            <div class="col-xs-12">
            <textarea type="text" id="edit-notes" name="edit-notes" placeholder="Notes"
                      class="width-100"> <?php echo e($location->notes); ?></textarea>
            </div>
        </div>

        <div class="form-group">
            <div class="col-xs-12">
                <div class="dropzone" id="editfiles"></div>
            </div>
        </div>

        <div class="clearfix form-actions">
            <div class="col-md-3 col-md-9">
                <button class="btn btn-success btn-edit-submit" type="submit" id="edit-submit-all">
                    <i class="ace-icon fa fa-save fa-fw bigger-110"></i> Save changes
                </button>
            </div>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>